let slideIndex=1;
let remaining=70000;

function setTime(){
    if(remaining==0) return;
    let h=Math.floor(remaining/3600);
    let m=Math.floor((remaining%3600/60));
    let s=(remaining%3600)%60;
    document.querySelector('#hours').innerHTML=h
    document.querySelector('#minutes').innerHTML=m
    document.querySelector('#seconds').innerHTML=s
}

setInterval(()=>{
    remaining-=1;
    setTime()
},1000)

function setSlide(input,index)
{
    slideIndex=index;
    let item=document.querySelector(`#${input}`)
    let slides=[...document.querySelector('.slides').children];
    slides.forEach((Element)=>{
        Element.classList.remove('active');
    })
    item.classList.add('active')
}   

setInterval(() => {
    slideIndex+=1;
    if(slideIndex==4){
        slideIndex=1;
    }
    setSlide(`slide${slideIndex}`,slideIndex)
}, 3000);